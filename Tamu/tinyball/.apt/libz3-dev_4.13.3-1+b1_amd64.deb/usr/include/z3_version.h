// automatically generated file.
#define Z3_MAJOR_VERSION   4
#define Z3_MINOR_VERSION   13
#define Z3_BUILD_NUMBER    3
#define Z3_REVISION_NUMBER 0

#define Z3_FULL_VERSION    "4.13.3.0"
/* #undef Z3GITHASH */
